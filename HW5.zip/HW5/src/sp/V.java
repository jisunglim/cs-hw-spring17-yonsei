package sp;

import heap.Key;

/**
 * Vertex class
 *
 * int v, vertex number; this number is invariant.
 * int d, distance; known (explored) distance from source to this vertex.
 * int i, information; estimated distance from this vertex to destination.
 */
public class V implements Key {
  public final int v;
  public int d;
  public int i;

  public V(int vertex, int dist, int info) {
    v = vertex;
    d = dist;
    i = info;
  }

  @Override
  public int id() {
    return v;
  }

  @Override
  public int key() {
    if (d == Integer.MAX_VALUE) return d;
    return d + i;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    V v1 = (V) o;

    return v == v1.v;
  }

  @Override
  public int hashCode() {
    return v;
  }

  @Override
  public String toString() {
    return String.format("v:%2d[ %5s + %5s ] ", v, d == Integer.MAX_VALUE ? "M" : d, i);
  }
}