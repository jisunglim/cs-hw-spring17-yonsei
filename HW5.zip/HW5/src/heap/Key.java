package heap;

/**
 * Interface supporting integer key.
 */
public interface Key {

  int id();
  int key();
}
